// import loginBackgroundImage from './loginBackgroundImage.png';

// export {
//     loginBackgroundImage
// };