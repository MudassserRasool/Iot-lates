import { Component } from '@angular/core';

@Component({
  selector: 'app-reuseable-form-add-button',
  templateUrl: './reuseable-form-add-button.component.html',
  styleUrls: ['./reuseable-form-add-button.component.scss']
})
export class ReuseableFormAddButtonComponent {

}
