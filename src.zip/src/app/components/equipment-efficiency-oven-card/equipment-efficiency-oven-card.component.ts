import { Component } from '@angular/core';

@Component({
  selector: 'app-equipment-efficiency-oven-card',
  templateUrl: './equipment-efficiency-oven-card.component.html',
  styleUrls: ['./equipment-efficiency-oven-card.component.scss']
})
export class EquipmentEfficiencyOvenCardComponent {

}
