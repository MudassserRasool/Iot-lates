import { Component } from '@angular/core';

@Component({
  selector: 'app-equipment-efficiency-detail-card',
  templateUrl: './equipment-efficiency-detail-card.component.html',
  styleUrls: ['./equipment-efficiency-detail-card.component.scss']
})
export class EquipmentEfficiencyDetailCardComponent {

}
