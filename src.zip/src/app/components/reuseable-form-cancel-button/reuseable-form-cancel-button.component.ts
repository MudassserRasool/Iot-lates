import { Component } from '@angular/core';

@Component({
  selector: 'app-reuseable-form-cancel-button',
  templateUrl: './reuseable-form-cancel-button.component.html',
  styleUrls: ['./reuseable-form-cancel-button.component.scss']
})
export class ReuseableFormCancelButtonComponent {

}
